<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\PusherServiceProvider::class,
    Srmklive\PayPal\Providers\PayPalServiceProvider::class
];
