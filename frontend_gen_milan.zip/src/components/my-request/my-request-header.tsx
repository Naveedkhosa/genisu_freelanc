const MyRequestHeader = () => {
    return (
        <div className='flex justify-between w-full my-5'>
            <div className='flex items-center gap-3'>
                <h2 className='mr-3 text-xl font-bold'>My Requests</h2>
            </div>
        </div>
    )
}

export default MyRequestHeader